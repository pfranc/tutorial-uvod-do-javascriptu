let pole = [25, "Ahoj", false, "Asterix"];

// pole[2] = true;
// pole.push("Obelix");
// pole.unshift("Panoramix");

// pole.push("říman", "říman", "říman");

// console.log(pole);
// let riman = pole.pop();

// console.log(pole);
// console.log("Vyhozeno z konce: " + riman);

// let panoramix =  pole.shift();
// console.log(pole);
// console.log("Vyhozeno ze začátku: " + panoramix);

console.log(pole);
console.log(pole.indexOf("Asterix"));
